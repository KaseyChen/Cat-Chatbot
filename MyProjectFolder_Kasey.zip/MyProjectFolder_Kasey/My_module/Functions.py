
# coding: utf-8

# ### Functions

# In[ ]:


"""

Code from Assignment 3

"""

# Is it a question
def is_question(input_string):
    if '?' in input_string:
        output = True
    else:
        output = False
    return output

# Removing puntuation
def remove_punctuation(input_string):
    out_string = ''
    for char in input_string:
        if char in string.punctuation:
            continue
        else:
            out_string = out_string + char
    return out_string

# Prep input text
def prepare_text(input_string):
    for char in input_string:
        temp_string = input_string.lower()
        temp_string = remove_punctuation(temp_string)
        out_list = temp_string.split()
    return out_list

# Response echo
def respond_echo(input_string, number_of_echoes, spacer):
    echo_output = ''
    if input_string is not None:
        echo_output = (input_string + spacer) * number_of_echoes
    if input_string == None:
        echo_output = None
    return echo_output

# Selecting an output
def selector(input_list, check_list, return_list):
    output = None
    for char in input_list:
        if char in check_list:
            output = random.choice(return_list)
            break
    return output

# Put together strings
def string_concatenator(string1, string2, separator):
    output = string1 + separator +string2
    return output

# Turning lists of strings into one
def list_to_string(input_list, separator):
    output = input_list[0]
    for item in input_list[1:]:
        output = string_concatenator(output, item, separator)
    return output

# Ending chat
def end_chat(input_list):
    if 'quit' in input_list:
        return True
    else:
        return False

# Check if any element of list_one is in list_two
def is_in_list(list_one, list_two):
    for element in list_one:
        if element in list_two:
            return True
    return False

# Find and return an element from list_one that is in list_two, or None otherwise
def find_in_list(list_one, list_two):
    for element in list_one:
        if element in list_two:
            return element
    return None


# ### Chatbot Code

# In[ ]:


""" 
The code below is taken from assignment 3 as well. 

All unique code that I typed myself will be clearly marked below in docstring.

If not marked, the code is taken from assignment 3.

"""

def my_cat():
    
    chat = True
    
    counter = 0
    
    while chat:

        msg = input('INPUT :\t')        
        out_msg = None
        
        question = is_question(msg)
        msg = prepare_text(msg)
        
        if end_chat(msg):
            out_msg = "Don't leave me yet :("
            chat = False

        if not out_msg:
            outs = []

            outs.append(selector(msg, GREETINGS_IN, GREETINGS_OUT))

            outs.append(selector(msg, FOOD_IN, FOOD_OUT))
            
            outs.append(respond_echo(selector(msg, MEOW_IN, MEOW_OUT), 3,''))

            if is_in_list(msg, PEOPLE_IN):
                name = find_in_list(msg, PEOPLE_IN)
                outs.append(list_to_string([PEOPLE_NAMES[name], name.capitalize(),
                                            selector(msg, PEOPLE_IN, PEOPLE_OUT)], ' '))
                
            if is_in_list(msg, NONO_IN):
                outs.append(list_to_string([selector(msg, NONO_IN, NONO_OUT), find_in_list(msg, NONO_IN)], ' '))

            """
            Unique code starts here.
        
            """
            #counter for word dog --> end chat if dog related word is said 3 or more times
            if is_in_list(msg, DOG_IN):
                counter += 1
                if counter >= 3:
                    outs.append(selector(msg, DOG_IN, ANGRY_OUT))
                    chat = False
            
            # getting the cat wet, which ends the chat automatically
            if is_in_list(msg, WATER_IN):
                outs.append(selector(msg, WATER_IN, ANGRY_OUT))
                chat = False
                
            outs.append(selector(msg, SINK_IN, SINK_OUT))
            
            # specific responses for vague words like yes, no, what, etc.
            outs.append(selector(msg, NO_IN, NO_OUT))
            
            outs.append(selector(msg, YES_IN, YES_OUT))
            
            outs.append(selector(msg, GOOD_IN, GOOD_OUT))
            
            outs.append(selector(msg, BAD_IN, BAD_OUT))
            
            # responses to inputs of confusion
            outs.append(selector(msg, WHAT_IN, WHAT_OUT))
            
            # responses to getting called fat after too many treats
            outs.append(selector(msg, FAT_IN, FAT_OUT))
            
            # responses to the word dog
            if is_in_list(msg, DOG_IN):
                outs.append(selector(msg, DOG_IN, DOG_OUT))
            
            # have reaction to sleep  --> belly rub to sleep
            if is_in_list(msg, TIRED_IN):
                    outs.append(selector(msg, TIRED_IN, TIRED_OUT))
                    
            #places to sleep or nap
            outs.append(selector(msg, SLEEPING_IN, SLEEPING_OUT))
            
            if is_in_list(msg, SLEEPING_IN):
                name = find_in_list(msg, SLEEPING_IN)
                outs.append(list_to_string([SLEEPING_NAMES[name], name.capitalize(),
                                            selector(msg, SLEEPING_IN, SLEEPING_OUT)], ' '))
                    
            # giving treats
            outs.append(selector(msg, TREAT_IN, TREAT_OUT))
            
            if is_in_list(msg, TREATS_IN):
                name = find_in_list(msg, TREATS_IN)
                outs.append(list_to_string([TREATS_NAMES[name], name.capitalize(),
                                            selector(msg, TREATS_IN, TREATS_OUT)], ' '))
                
            # rub belly and head pat
            outs.append(selector(msg, PET_IN, PET_OUT))
            
            # playing with toys
            outs.append(selector(msg, TOY_IN, TOY_OUT))
            
            if is_in_list(msg, TOYS_IN):
                name = find_in_list(msg, TOYS_IN)
                outs.append(list_to_string([TOYS_NAMES[name], name.capitalize(),
                                            selector(msg, TOYS_IN, TOYS_OUT)], ' '))
                
            #respond to what are you doing
            outs.append(selector(msg, YOU_IN, YOU_OUT))
            
            #code taking the user through a walk with the cat
            outs.append(selector(msg, WALK_IN, WALK_OUT))
            
            outs.append(selector(msg, WALKING_IN, WALKING_OUT))
            
            outs.append(selector(msg, WALK_IN, WALK_OUT))
            
            outs.append(selector(msg, PARK_IN, PARK_OUT))
            
            # taking the longer path, ending the chat
            outs.append(selector(msg, LONG_IN, LONG_OUT))
            
            if is_in_list(msg, WET_IN):
                outs.append(selector(msg, WET_IN, WET_OUT))
                chat = False
                
            # taking the short path, ending the chat 
            if is_in_list(msg, SHORT_IN):
                outs.append(selector(msg, SHORT_IN, SHORT_OUT))
                chat = False
            
            
            """
            Unique code ends here.
            
            """
            
            options = list(filter(None, outs))
            if options:
                out_msg = random.choice(options)

        if not out_msg and question:
            out_msg = random.choice(QUESTION)

        if not out_msg:
            out_msg = random.choice(UNKNOWN)

        print('OUTPUT:', out_msg)

