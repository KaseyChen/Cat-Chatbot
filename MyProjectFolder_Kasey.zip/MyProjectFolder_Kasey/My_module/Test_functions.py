
# coding: utf-8

# ### Test Function

# In[ ]:


assert callable(is_in_list)
assert isinstance(is_in_list(['a', 'b'], ['b', 'c']), bool)
assert is_in_list(['a', 'b'], ['b', 'c']) == True

